-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2024 at 04:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbfenndy56`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbfenndy56`
--

CREATE TABLE `tbfenndy56` (
  `NAMA` varchar(20) NOT NULL,
  `UMUR` varchar(2) NOT NULL,
  `ALAMAT` varchar(100) NOT NULL,
  `SETATUS` varchar(50) NOT NULL,
  `NOHP/GMAIL` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbfenndy56`
--

INSERT INTO `tbfenndy56` (`NAMA`, `UMUR`, `ALAMAT`, `SETATUS`, `NOHP/GMAIL`) VALUES
('fendi nugroho', '16', 'kalibening ', 'pelajar', 'toschoolfenndy56@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbfenndy56`
--
ALTER TABLE `tbfenndy56`
  ADD PRIMARY KEY (`NAMA`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
